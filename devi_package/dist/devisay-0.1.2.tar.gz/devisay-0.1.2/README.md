# devi

A simple Python package that prints funny messages with ASCII faces.

## Usage

```python
from devi import devi

devi.bullies()
devi.greets()
devi.beingfunny(