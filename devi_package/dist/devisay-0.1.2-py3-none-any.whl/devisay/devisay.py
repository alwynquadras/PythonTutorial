class devisay:
    @staticmethod
    def bullies():
        print("randemaga, you're a dissapointment to your parents.")
        print(r"""
  >:(
 (o_o)
 /| |\
  / \
""")

    @staticmethod
    def greets():
        print("Bevarsi encha ulla")
        print(r"""
  (^_^)
  (   )
  /   \
""")

    @staticmethod
    def beingfunny():
        print("thangabali punkbali")
        print(r"""
  XD
 ( ^.^ )
  (   )
""")
        

